function showData(data)
{
    $("#displayarea").text(data);
}

$(window).on("load", function() 
{
    $("#fetchBtn").on("click", function()
    {
        // Your code here!
        // ...
        // showData("...");        
    });
    
    showData("No data retrieved yet");
});
